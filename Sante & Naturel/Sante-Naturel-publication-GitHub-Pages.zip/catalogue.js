const catalogueProducts = [
    { name: 'ABSORBENT C', image: 'ABSORBANT C.jpeg', category: 'nutrition', search: 'vitamine c immunite fatigue collagene energie', benefits: ['La vitamine C contribue au fonctionnement normal du système immunitaire.', 'Elle contribue à réduire la fatigue et à la formation normale de collagène.', 'Elle participe au métabolisme énergétique normal.'] },
    { name: 'FOREVER CALCIUM', image: 'FOREVER CALCIUM.jpeg', category: 'nutrition', search: 'calcium magnesium vitamine c vitamine d zinc os dentition muscles', benefits: ['Le calcium et la vitamine D contribuent au maintien d’une ossature normale.', 'Le calcium contribue au maintien d’une dentition normale.', 'Le calcium contribue au fonctionnement normal des muscles.'] },
    { name: 'BEE POLLEN', image: 'FOREVER BEE POLLEN.jpeg', category: 'nutrition', search: 'pollen abeille nutriments vitalite', benefits: ['Apporte des nutriments naturellement présents dans le pollen d’abeille.', 'Contribue à la vitalité au quotidien.'] },
    { name: 'MULTI-MACA', image: 'FOREVER MULTI-MACA.jpeg', category: 'nutrition', search: 'maca vitalite energie tonus', benefits: ['La maca est traditionnellement appréciée pour accompagner la vitalité.', 'S’intègre à une routine quotidienne axée sur le tonus et le bien-être.', 'Convient aux routines bien-être des hommes et des femmes.'] },
    { name: 'BEE PROPOLIS', image: 'FOREVER BEE PROPOLIS.jpeg', category: 'nutrition', search: 'propolis ruche abeille antioxydant immunite defenses naturelles', benefits: ['La propolis est appréciée pour ses propriétés antioxydantes.', 'Contribue au maintien des défenses naturelles.'] },
    { name: 'LYCIUM PLUS', image: 'FOEVER LYCIUM PLUS.jpeg', category: 'nutrition', search: 'goji lycium reglisse antioxydants vitalite stress oxydatif cellules', benefits: ['Les baies de goji sont naturellement riches en composés antioxydants.', 'Les composés antioxydants du goji contribuent à protéger les cellules du stress oxydatif.', 'Accompagne une routine quotidienne axée sur la vitalité.'] },
    { name: 'AIL & THYM', image: 'FOREVER AIL & THYM.jpeg', category: 'nutrition', search: 'ail thym digestion vitalite confort digestif bien-etre cardiovasculaire', benefits: ['Le thym est traditionnellement apprécié pour accompagner le confort digestif.', 'L’ail contribue à une routine alimentaire axée sur le bien-être cardiovasculaire.', 'La formule associe les bienfaits traditionnels de l’ail et du thym.'] },
    { name: 'VITOLIZE HOMMES', image: 'VITOLIZ HOMME.jpeg', category: 'nutrition', search: 'vitolize citrouille vitamines b6 c d e zinc homme vitalite energie testosterone', benefits: ['Contribue au bien-être et à la vitalité masculine.', 'Les vitamines B6 et C contribuent au métabolisme énergétique normal.', 'Le zinc contribue au maintien d’un taux normal de testostérone dans le sang.'] },
    { name: 'ALOE BERRY NECTAR', image: 'ALEO BERRY NECTAR.jpeg', category: 'boissons', search: 'aloe berry nectar boisson aloe vera canneberge pomme hydratation', benefits: ['Contribue à varier l’hydratation quotidienne.', 'Sa saveur fruitée rend l’hydratation quotidienne plus agréable.'] },
    { name: 'ALOE VERA GEL', image: 'aloe-vera-gel-forever.png', category: 'boissons', search: 'aloe vera gel boisson hydratation rafraichissant bien-etre', benefits: ['Boisson à l’aloe vera au goût doux et rafraîchissant.', 'Contribue à l’hydratation quotidienne.', 'S’intègre facilement à une routine de bien-être.'] },
    { name: 'BOISSONS À L’ALOE VERA', image: 'boissons-aloe-forever.png', category: 'boissons', search: 'mango berry nectar gel peaches boisson hydratation fraicheur', benefits: ['Des saveurs fruitées pour varier l’hydratation au quotidien.', 'Une boisson fraîche et agréable à intégrer à la routine quotidienne.'] },
    { name: 'SOINS À L’ALOE VERA', image: 'aloe-soins-forever.png', category: 'soins', search: 'aloe first gelly propolis creme peau rafraichit apaise hydrate confort cutane nourrit adoucit', benefits: ['Aloe First rafraîchit et apaise la peau.', 'Aloe Vera Gelly hydrate et procure une sensation de confort cutané.', 'Aloe Propolis Creme nourrit et adoucit la peau.'] },
    { name: 'KIT VISAGE À L’ALOE', image: 'kit-visage-aloe-forever.jpeg', category: 'soins', search: 'gelly propolis creme savon avocado peau nettoie hydrate fraicheur nourrit adoucit', benefits: ['Nettoie la peau en douceur avec le savon Aloe Avocado.', 'Aloe Vera Gelly hydrate et procure une sensation de fraîcheur.', 'Aloe Propolis Creme nourrit et adoucit la peau.'] }
];

const catalogueCategories = [
    { id: 'nutrition', title: 'Nutrition & vitalité', description: 'Une sélection de compléments et de produits de la ruche.' },
    { id: 'boissons', title: 'Boissons à l’aloe vera', description: 'Des boissons et saveurs variées à découvrir.' },
    { id: 'soins', title: 'Soins & beauté', description: 'Des soins et produits cosmétiques pour votre routine.' }
];
const catalogueStorageKey = 'sante-naturel-product-stock-v1';
const searchInput = document.getElementById('product-search');
const availabilityFilter = document.getElementById('stock-filter');
const resultsMessage = document.getElementById('search-results');
const storageMessage = document.getElementById('stock-storage-status');
const categoryContainer = document.getElementById('product-categories');
const normalizeCatalogueText = (value) => value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('fr')
    .trim();
const catalogueProductId = (name) => normalizeCatalogueText(name).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

let catalogueStock = {};
let catalogueStorageAvailable = true;

try {
    const storedStock = localStorage.getItem(catalogueStorageKey);
    if (storedStock) {
        const parsedStock = JSON.parse(storedStock);
        if (!parsedStock || Array.isArray(parsedStock) || typeof parsedStock !== 'object'
            || Object.values(parsedStock).some((value) => typeof value !== 'boolean')) {
            throw new Error('Le format des stocks enregistrés est invalide.');
        }
        catalogueStock = parsedStock;
    }
} catch (error) {
    console.error('Impossible de charger les stocks enregistrés.', error);
    catalogueStorageAvailable = false;
    storageMessage.textContent = 'Impossible de charger les stocks enregistrés.';
    storageMessage.classList.add('text-red-700');
}

const makeProductCard = (product) => {
    const productId = catalogueProductId(product.name);
    const available = catalogueStock[productId] === true;
    const whatsappMessage = available
        ? `Bonjour Santé & Naturel, je souhaite commander ${product.name}.`
        : `Bonjour Santé & Naturel, pouvez-vous m’informer de la disponibilité de ${product.name} ?`;
    const card = document.createElement('article');
    card.className = 'ice-card flex flex-col overflow-hidden rounded-3xl border border-sky-100 bg-white transition hover:-translate-y-1 hover:border-sky-200';
    card.dataset.productCard = '';
    card.dataset.category = product.category;
    card.dataset.search = normalizeCatalogueText(`${product.name} ${product.search} ${product.benefits.join(' ')}`);

    const imageFrame = document.createElement('div');
    imageFrame.className = 'flex h-64 items-center justify-center border-b border-sky-50 bg-gradient-to-br from-white to-sky-50 p-5';
    const image = document.createElement('img');
    image.src = product.image;
    image.alt = product.name;
    image.className = 'h-full w-full object-contain';
    image.loading = 'lazy';
    imageFrame.append(image);

    const body = document.createElement('div');
    body.className = 'flex flex-1 flex-col gap-5 p-6';
    const title = document.createElement('h3');
    title.className = 'text-lg font-bold text-slate-900';
    title.textContent = product.name;
    const benefits = document.createElement('ul');
    benefits.className = 'space-y-2 text-sm leading-6 text-slate-600';
    product.benefits.forEach((benefit) => {
        const item = document.createElement('li');
        item.className = 'flex gap-2';
        item.innerHTML = '<i class="fas fa-check mt-1 text-xs text-snGreen" aria-hidden="true"></i>';
        const text = document.createElement('span');
        text.textContent = benefit;
        item.append(text);
        benefits.append(item);
    });

    const stockRow = document.createElement('div');
    stockRow.className = 'mt-auto flex flex-wrap items-center justify-between gap-3 border-t border-sky-50 pt-4';
    const status = document.createElement('span');
    status.dataset.stockStatus = '';
    status.className = available
        ? 'rounded-full bg-cyan-100 px-3 py-1 text-xs font-semibold text-cyan-900'
        : 'rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600';
    status.textContent = available ? 'Disponible' : 'Indisponible';
    status.setAttribute('aria-label', `Stock ${available ? 'disponible' : 'indisponible'}`);

    const stockToggle = document.createElement('button');
    stockToggle.type = 'button';
    stockToggle.dataset.stockToggle = '';
    stockToggle.className = 'rounded-xl border border-sky-200 px-3 py-2 text-xs font-semibold text-snGreen transition hover:bg-sky-50 disabled:cursor-not-allowed disabled:opacity-50';
    stockToggle.textContent = available ? 'Marquer indisponible' : 'Marquer disponible';
    stockToggle.setAttribute('aria-label', `Modifier le stock de ${product.name}`);
    stockToggle.disabled = !catalogueStorageAvailable;
    stockRow.append(status, stockToggle);

    const orderLink = document.createElement('a');
    orderLink.className = 'inline-flex w-full items-center justify-center gap-2 rounded-xl bg-snGreen px-4 py-3 text-sm font-bold text-white transition hover:bg-snLightGreen';
    orderLink.href = `https://wa.me/221772702493?text=${encodeURIComponent(whatsappMessage)}`;
    orderLink.target = '_blank';
    orderLink.rel = 'noopener noreferrer';
    orderLink.dataset.orderLink = '';
    orderLink.innerHTML = '<i class="fab fa-whatsapp text-lg" aria-hidden="true"></i>';
    const orderLabel = document.createElement('span');
    orderLabel.textContent = available ? 'Commander sur WhatsApp' : 'Demander la disponibilité';
    orderLink.append(orderLabel);

    const updateProductAvailability = (nextAvailable) => {
        catalogueStock = { ...catalogueStock, [productId]: nextAvailable };
        status.textContent = nextAvailable ? 'Disponible' : 'Indisponible';
        status.className = nextAvailable
            ? 'rounded-full bg-cyan-100 px-3 py-1 text-xs font-semibold text-cyan-900'
            : 'rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600';
        status.setAttribute('aria-label', `Stock ${nextAvailable ? 'disponible' : 'indisponible'}`);
        stockToggle.textContent = nextAvailable ? 'Marquer indisponible' : 'Marquer disponible';
        orderLabel.textContent = nextAvailable ? 'Commander sur WhatsApp' : 'Demander la disponibilité';
        orderLink.href = `https://wa.me/221772702493?text=${encodeURIComponent(nextAvailable
            ? `Bonjour Santé & Naturel, je souhaite commander ${product.name}.`
            : `Bonjour Santé & Naturel, pouvez-vous m’informer de la disponibilité de ${product.name} ?`)}`;
    };

    stockToggle.addEventListener('click', () => {
        const nextAvailable = catalogueStock[productId] !== true;
        const updatedStock = { ...catalogueStock, [productId]: nextAvailable };
        try {
            localStorage.setItem(catalogueStorageKey, JSON.stringify(updatedStock));
        } catch (error) {
            console.error(`Impossible d’enregistrer le stock de ${product.name}.`, error);
            catalogueStorageAvailable = false;
            storageMessage.textContent = 'Impossible d’enregistrer les stocks. Vérifiez les paramètres de stockage du navigateur.';
            storageMessage.classList.add('text-red-700');
            categoryContainer.querySelectorAll('[data-stock-toggle]').forEach((button) => {
                button.disabled = true;
            });
            return;
        }
        updateProductAvailability(nextAvailable);
        applyCatalogueFilters();
    });

    body.append(title, benefits, stockRow, orderLink);
    card.append(imageFrame, body);
    return card;
};

catalogueCategories.forEach((category) => {
    const section = document.createElement('section');
    section.id = category.id;
    section.className = 'anchor-section';
    const heading = document.createElement('div');
    heading.className = 'mb-5';
    const title = document.createElement('h2');
    title.className = 'text-2xl font-bold text-slate-900 sm:text-3xl';
    title.textContent = category.title;
    const description = document.createElement('p');
    description.className = 'mt-2 text-sm text-slate-600';
    description.textContent = category.description;
    const grid = document.createElement('div');
    grid.className = 'grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3';
    grid.dataset.categoryGrid = category.id;

    catalogueProducts.filter((product) => product.category === category.id).forEach((product) => {
        grid.append(makeProductCard(product));
    });

    heading.append(title, description);
    section.append(heading, grid);
    categoryContainer.append(section);
});

if (catalogueStorageAvailable) {
    storageMessage.textContent = 'Les statuts de disponibilité sont enregistrés automatiquement sur cet appareil.';
}

function applyCatalogueFilters() {
    const query = normalizeCatalogueText(searchInput.value);
    const selectedAvailability = availabilityFilter.value;
    let visibleCount = 0;

    categoryContainer.querySelectorAll('[data-product-card]').forEach((card) => {
        const isAvailable = catalogueStock[catalogueProductId(card.querySelector('h3').textContent)] === true;
        const matchesQuery = card.dataset.search.includes(query);
        const matchesAvailability = selectedAvailability === 'all'
            || (selectedAvailability === 'available' && isAvailable)
            || (selectedAvailability === 'unavailable' && !isAvailable);
        const isVisible = matchesQuery && matchesAvailability;
        card.classList.toggle('hidden', !isVisible);
        if (isVisible) visibleCount += 1;
    });

    categoryContainer.querySelectorAll('[data-category-grid]').forEach((grid) => {
        const hasVisibleProducts = Array.from(grid.children).some((card) => !card.classList.contains('hidden'));
        grid.closest('section').classList.toggle('hidden', !hasVisibleProducts);
    });

    resultsMessage.textContent = visibleCount === 0
        ? 'Aucun produit trouvé avec ces critères.'
        : `${visibleCount} produit${visibleCount > 1 ? 's' : ''} affiché${visibleCount > 1 ? 's' : ''}.`;
}

searchInput.addEventListener('input', applyCatalogueFilters);
availabilityFilter.addEventListener('change', applyCatalogueFilters);
applyCatalogueFilters();
