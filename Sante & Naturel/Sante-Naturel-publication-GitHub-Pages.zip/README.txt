SANTE & NATUREL - SITE WEB ET APPLICATION INSTALLABLE

PUBLICATION GRATUITE AVEC GITHUB PAGES
1. Connectez-vous a GitHub et creez un nouveau depot public vide, par exemple
   « sante-naturel-site ». N'ajoutez pas de README, licence ni .gitignore.
2. Extrayez tous les fichiers de cette archive dans un dossier.
3. Dans le nouveau depot, choisissez « Add file » > « Upload files » et
   importez les fichiers extraits a la racine.
4. Validez l'envoi dans la branche « main ».
5. Dans « Settings » > « Pages », sous « Build and deployment », choisissez
   « Deploy from a branch », puis « main » et « /(root) », et enregistrez.
6. Attendez quelques minutes. L'adresse publique sera
   https://VOTRE-IDENTIFIANT.github.io/NOM-DU-DEPOT/.

INSTALLER L'APPLICATION
Ouvrez l'adresse publique HTTPS, puis choisissez « Installer l'application »
dans le menu lateral du site. Sur iPhone/iPad, utilisez Safari > Partager >
« Sur l'ecran d'accueil ». Le site doit etre publie en HTTPS pour l'installation.

HORS LIGNE ET LIMITES
Une fois les pages chargees, les pages et images essentielles sont disponibles
hors ligne. Certains styles et polices sont charges depuis Internet lors de la
premiere visite. Les commandes WhatsApp necessitent une connexion.

Le panier et les disponibilites de stock sont conserves dans le navigateur
utilise et ne sont pas synchronises entre appareils.
