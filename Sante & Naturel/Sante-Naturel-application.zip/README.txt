SANTE & NATUREL - APPLICATION INSTALLABLE

INSTALLATION
Le site est une application web progressive (PWA). Pour l'installer, il doit
etre publie sur une adresse HTTPS. L'ouverture directe de index.html depuis
une archive ou un dossier (adresse file://) ne permet pas l'installation.

1. Publiez tous les fichiers de cette archive sur un hebergement HTTPS.
2. Ouvrez l'adresse du site dans Chrome, Edge ou Safari.
3. Ouvrez le menu lateral du site et choisissez « Installer l'application ».
   Si le navigateur n'affiche pas sa fenetre d'installation, utilisez son menu :
   - Android : « Installer l'application » ou « Ajouter a l'ecran d'accueil ».
   - iPhone/iPad : Safari > Partager > « Sur l'ecran d'accueil ».
   - Windows : Chrome/Edge > menu du navigateur > Installer l'application.

Une fois le site charge, les pages et les images essentielles sont disponibles
hors ligne. Certains styles et polices sont charges depuis Internet lors de la
premiere visite. Les commandes WhatsApp necessitent une connexion.

Le panier et les disponibilites de stock restent enregistres dans le navigateur
de l'appareil et ne sont pas synchronises entre plusieurs appareils.
