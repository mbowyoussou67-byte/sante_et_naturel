SANTE & NATUREL - SITE WEB

UTILISATION
1. Extrayez tous les fichiers de cette archive dans un même dossier.
2. Ouvrez index.html dans un navigateur récent.
3. Utilisez le menu pour accéder à la boutique, au catalogue, aux produits,
   aux informations sur la boutique et au contact.

CONNEXION INTERNET
Une connexion Internet est nécessaire pour charger Tailwind CSS, les icones
Font Awesome, la police Poppins et pour envoyer une commande sur WhatsApp.

DONNEES LOCALES
Le panier et les disponibilites de stock sont conserves dans le navigateur
et sur l'appareil utilisé. Ils ne sont pas synchronises entre appareils.
